package Edairy;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Category{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton insertButton,deleteButton,updateButton,viewButton;
	private JPanel p1,p2,p3,p;
	private JLabel lblcategory_id,lblcategory_name,lblprice,lblavailability,lblcode;
	private JTextField txtcategory_id,txtcategory_name,txtprice,txtavailability,txtcode;
	
	private List category_idList;
	Connection con;ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public Category(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		
		
		lblcategory_id=new JLabel("Category ID");
		lblcategory_name=new JLabel("Category Name");
		lblprice=new JLabel("Price");
		lblavailability=new JLabel("Availability");
		lblcode = new JLabel("Code");
		
		
		txtcategory_id=new JTextField(15);
		txtcategory_name=new JTextField(15);
		txtprice=new JTextField(8);
		txtavailability=new JTextField(15);
		txtcode = new JTextField(15);
		
		
		this.p=p;
		
		
		
	}

	public void connectToDB() 
    {
		try {
		  
		
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","joshua","vasavi");  
		  
		 
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		
		
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
		
		
	}
	public void loadcategoryIDs() {
		try {
			category_idList.removeAll();
			rs=statement.executeQuery("select category_id from Category");
			while(rs.next()) {
				category_idList.add(rs.getString("category_id"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}

	public void buildGUI() {
		
		
		
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				insertButton=new JButton("Submit");
				txtcategory_id.setText(null);
				txtcategory_name.setText(null);
				txtprice.setText(null);
				txtavailability.setText(null);
				txtcode.setText(null);
				
				
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(5,2));
				 p1.add(lblcategory_id);
				 p1.add(txtcategory_id);
				 p1.add(lblcategory_name);
				 p1.add(txtcategory_name);
				 p1.add(lblprice);
				 p1.add(txtprice);
				 p1.add(lblavailability);
				 p1.add(txtavailability);
				 p1.add(lblcode);
				 p1.add(txtcode);
				 p3=new JPanel(new FlowLayout());
				 p3.add(insertButton);
				 //p1.add(txtf1);
				 //p3.setBackground(Color.yellow);
				 p1.setBounds(100,80,300,250);p3.setBounds(200,400,75,35);
				 //p1.setBackground(Color.pink) ;
				 p2 = new JPanel(new FlowLayout());
					 category_idList=new List(10);
					 loadcategoryIDs();
					 p2.add(category_idList);//p2.setBackground(Color.cyan) ;
					 p2.setBounds(320,150,350,180);
				 p. add(p1);p.add(p3);
				 p. add(p2);
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(600,600);
					frame.validate();
					
				 insertButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO Category VALUES('"+txtcategory_id.getText()+"','"+txtcategory_name.getText()+"','"+txtprice.getText()+"','"+txtcode.getText()+"','"+txtavailability.getText()+"')";
					
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\ninserted "+i+" rows succesfully");loadcategoryIDs();
					
					
					
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				
				 }
			
			
				 	});
			}
			});

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("Delete");
				
				txtcategory_id.setText(null);
				txtcategory_name.setText(null);
				txtprice.setText(null);
				txtavailability.setText(null);
				txtcode.setText(null);
				
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				p1.setLayout(new GridLayout(5,2));
				 p1.add(lblcategory_id);
				 p1.add(txtcategory_id);
				 p1.add(lblcategory_name);
				 p1.add(txtcategory_name);
				 p1.add(lblprice);
				 p1.add(txtprice);
				 p1.add(lblavailability);
				 p1.add(txtavailability);
				 p1.add(lblcode);
				 p1.add(txtcode);
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				 //p1.add(txtf1);
				 //p3.setBackground(Color.yellow);
				 p1.setBounds(100,80,300,250);p3.setBounds(200,400,75,35);
				 //p1.setBackground(Color.pink) ;
				 p2 = new JPanel(new FlowLayout());
					 category_idList=new List(10);
					 loadcategoryIDs();
					 p2.add(category_idList);//p2.setBackground(Color.cyan) ;
					 p2.setBounds(320,150,350,180);
				 p. add(p1);p.add(p3);
				 p. add(p2);
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(600,600);
					frame.validate();
				  category_idList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from Category");
								while (rs.next()) 
								{
									if (rs.getString("category_id").equals(category_idList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									
									txtcategory_id.setText(rs.getString("category_id"));
									txtcategory_name.setText(rs.getString("category_name"));
									txtprice.setText(rs.getString("price"));
									txtcode.setText(rs.getString("code"));
									txtavailability.setText(rs.getString("Availability"));
									
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});	
				
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					
					int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
					if(a==JOptionPane.YES_OPTION){  
					String query="DELETE FROM Category WHERE category_id="+category_idList.getSelectedItem();
				
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");loadcategoryIDs();
					}
					
					
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				updateButton = new JButton("Modify");
				txtcategory_id.setText(null);
				txtcategory_name.setText(null);
				txtprice.setText(null);
				txtavailability.setText(null);
				txtcode.setText(null);
				
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				p1.setLayout(new GridLayout(5,2));
				 p1.add(lblcategory_id);
				 p1.add(txtcategory_id);
				 p1.add(lblcategory_name);
				 p1.add(txtcategory_name);
				 p1.add(lblprice);
				 p1.add(txtprice);
				 p1.add(lblavailability);
				 p1.add(txtavailability);
				 p1.add(lblcode);
				 p1.add(txtcode);
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				 //p1.add(txtf1);
				 //p3.setBackground(Color.yellow);
				 p1.setBounds(100,80,300,250);p3.setBounds(200,400,75,35);
				 //p1.setBackground(Color.pink) ;
				 p2 = new JPanel(new FlowLayout());
					 category_idList=new List(10);
					 loadcategoryIDs();
					 p2.add(category_idList);//p2.setBackground(Color.cyan) ;
					 p2.setBounds(320,150,350,180);
				 p. add(p1);p.add(p3);
				 p. add(p2);
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(600,600);
					frame.validate();
				  category_idList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from Category");
								while (rs.next()) 
								{
									if (rs.getString("category_id").equals(category_idList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									
									txtcategory_id.setText(rs.getString("category_id"));
									txtcategory_name.setText(rs.getString("category_name"));
									txtprice.setText(rs.getString("price"));
									txtcode.setText(rs.getString("code"));
									txtavailability.setText(rs.getString("Availability"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});		
					
				
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 try {
								
								int a=JOptionPane.showConfirmDialog(p,"Are you sure want to update:");
								if(a==JOptionPane.YES_OPTION){  
								String query="update Category set category_name='"+txtcategory_name.getText()+"',price='"+txtprice.getText()+"',code='"+txtcode.getText()+"',Availability='"+txtavailability.getText()+"' WHERE category_id="+category_idList.getSelectedItem();
								
								int i=statement.executeUpdate(query);
								JOptionPane.showMessageDialog(p,"\nupdated "+i+" rows succesfully");loadcategoryIDs();
								}
								
								
							}
							catch(SQLException deleteException){
								displaySQLErrors(deleteException);
							}
				
				 }
			
			
				 	});
			}
			});
		
		view.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				Label view1=new Label("Category view");
				//view1.setAlignment(Label.CENTER); 
				Font myFont = new Font("Serif",Font.BOLD,40);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p1.add(view1);
				
				
				p2=new JPanel(new FlowLayout());
                p2.add(viewButton);
                p2.setBounds(220,220,75,35);
                p1.setBounds(130,20,300,100);
                p.add(p1);
                p.add(p2);
                p.setLayout(new BorderLayout());
                frame.add(p);
				
				
				
				frame.setSize(600,600);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						      
						    JTable j; 
						
						        f = new JFrame(); 
						  
						  
						        f.setTitle("Category details"); 
						        
						       
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						        
						       model.addColumn("Category id");
						       model.addColumn("Category Name");
						       model.addColumn("Price");
						       model.addColumn("code");
						       model.addColumn("availability");
						      
						      
						       try {
									
									rs=statement.executeQuery("select * from Category");
									while(rs.next()) {
										 model.addRow(new Object[]{ rs.getString("category_id"), rs.getString("category_name"),rs.getString("price"),rs.getString("code"),rs.getString("Availability")});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 300, 300); 
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp);
						        f.setSize(800, 400); 
						        f.setVisible(true);   
						    } 
				 	});				
			}			
		});
	}
}
