package Edairy;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class EdairyUI extends JFrame{
	private static final long serialVersionUID = 1L;
	private JMenuBar mnu;
	private JMenu mnulogin;
	private JMenu mnuDetails;
	private JMenu mnuCustomer;
	private JMenu mnuCategory;
	private JMenu mnuCompany;
	private JMenu mnuOrders;
	private JMenu mnuCustomer_login;
	private JMenu mnuOrders_from;
	private JMenu mnuSelects;
	private JMenuItem insert1,update1,delete1,view1;
	private JMenuItem insert2,update2,delete2,view2;
	private JMenuItem insert3,update3,delete3,view3;
	private JMenuItem insert4,update4,delete4,view4;
	private JMenuItem insert5,update5,delete5,view5;
	private JMenuItem insert6,update6,delete6,view6;
	private JMenuItem insert7,update7,delete7,view7;
	private JMenuItem insert8,update8,delete8,view8;
	private JMenuItem insert9,update9,delete9,view9;	
	private JLabel labelName;	
	private static JPanel p0,p1;	
	void initialize() {
		mnu=new JMenuBar();		
		mnulogin= new JMenu("Login");
		mnuCustomer= new JMenu("Customer");
		mnuCategory= new JMenu("Category");
		mnuCompany= new JMenu("Company");
		mnuDetails= new JMenu("Details");
		mnuOrders= new JMenu("Orders");
		mnuCustomer_login =  new JMenu("Customer_login");
		mnuOrders_from = new JMenu("Orders_from");
		mnuSelects = new JMenu("Selects");		
		labelName=new JLabel("DAIRY MANAGEMENT SYSTEM");
		 p1=new JPanel();
		p0=new JPanel();
		insert1=new JMenuItem("Insert");
		update1=new JMenuItem("Update");
		delete1=new JMenuItem("Delete");
		view1=new JMenuItem("View");
		insert2=new JMenuItem("Insert");
		update2=new JMenuItem("Update");
		delete2=new JMenuItem("Delete");
		view2=new JMenuItem("View");
		insert3=new JMenuItem("Insert");
		update3=new JMenuItem("Update");
		delete3=new JMenuItem("Delete");
		view3=new JMenuItem("View");
		insert4=new JMenuItem("Insert");
		update4=new JMenuItem("Update");
		delete4=new JMenuItem("Delete");
		view4=new JMenuItem("View");
		insert5=new JMenuItem("Insert");
		update5=new JMenuItem("Update");
		delete5=new JMenuItem("Delete");
		view5=new JMenuItem("View");
		insert6=new JMenuItem("Insert");
		update6=new JMenuItem("Update");
		delete6=new JMenuItem("Delete");
		view6=new JMenuItem("View");		
		insert7=new JMenuItem("Insert");
		update7=new JMenuItem("Update");
		delete7=new JMenuItem("Delete");
		view7=new JMenuItem("View");
		insert8=new JMenuItem("Insert");
		update8=new JMenuItem("Update");
		delete8=new JMenuItem("Delete");
		view8=new JMenuItem("View");		
		insert9=new JMenuItem("Insert");
		update9=new JMenuItem("Update");
		delete9=new JMenuItem("Delete");
		view9=new JMenuItem("View");
	}
	void addComponentsToFrame() {
		 //mnulogin.add(insert1);
		 mnulogin.add(delete1);
		 mnulogin.add(update1);
		 mnulogin.add(view1);
		 mnuCustomer.add(insert2);
		 mnuCustomer.add(delete2);
		 mnuCustomer.add(update2);
		 mnuCustomer.add(view2);
		 mnuCategory.add(insert3);
		 mnuCategory.add(delete3);
		 mnuCategory.add(update3);
		 mnuCategory.add(view3);
		 mnuCompany.add(insert4);
		 mnuCompany.add(delete4);
		 mnuCompany.add(update4);
		 mnuCompany.add(view4);
		 mnuDetails.add(insert5);
		 mnuDetails.add(delete5);
		 mnuDetails.add(update5);
		 mnuDetails.add(view5);
		 mnuOrders.add(insert6);
		 mnuOrders.add(delete6);
		 mnuOrders.add(update6);
		 mnuOrders.add(view6);
		 mnuOrders_from.add(insert7);
		 mnuOrders_from.add(delete7);
		 mnuOrders_from.add(update7);
		 mnuOrders_from.add(view7);
		 mnuSelects.add(insert8);
		 mnuSelects.add(delete8);
		 mnuSelects.add(update8);
		 mnuSelects.add(view8);
		 mnuCustomer_login.add(insert9);
		 mnuCustomer_login.add(delete9);
		 mnuCustomer_login.add(update9);
		 mnuCustomer_login.add(view9);	 
		 mnu.add(mnulogin);
		 mnu.add(mnuCustomer);
		 mnu.add(mnuCategory);
		 mnu.add(mnuCompany);
		 mnu.add(mnuDetails);
		 mnu.add(mnuOrders);
		 mnu.add(mnuOrders_from);
		 mnu.add(mnuSelects);
		 mnu.add(mnuCustomer_login);	 
		 setJMenuBar(mnu); 
		 p1.add(labelName);p1.setAlignmentY(CENTER_ALIGNMENT); 
		 p1.setBounds(500,500,800,100);	
		p0.add(p1);
		 add(p0);
	}
void closeWindow(){
		try {
			int a=JOptionPane.showConfirmDialog(this,"Are you sure want to Quit Dairy Management System:");
			if(a==JOptionPane.YES_OPTION){  
				JOptionPane.showMessageDialog(this,
					    "Thank you!\nExiting Dairy Management System","Quit",
					    JOptionPane.WARNING_MESSAGE);
				System.exit(0);
			}
			else if (a== JOptionPane.NO_OPTION) {
				setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			}
			else if (a== JOptionPane.CANCEL_OPTION) {
				setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			}
		}
			catch(Exception e) {
				System.out.println(e);
				}
	}
	void register() {	
		login log=new login(p0,EdairyUI.this,insert1,delete1,update1,view1);
		log.buildGUI();		
		Customer Cust=new Customer(p0,EdairyUI.this,insert2,delete2,update2,view2); 
		Cust.buildGUI();		
		Details det=new Details(p0,EdairyUI.this,insert5,delete5,update5,view5); 
		det.buildGUI();		
		Category cat=new Category(p0,EdairyUI.this,insert3,delete3,update3,view3); 
		cat.buildGUI();		
		Company cmp=new Company(p0,EdairyUI.this,insert4,delete4,update4,view4); 
		cmp.buildGUI();		
		Orders ord=new Orders(p0,EdairyUI.this,insert6,delete6,update6,view6); 
		ord.buildGUI();		
		Orders_from of = new Orders_from(p0,EdairyUI.this,insert7,delete7,update7,view7);
		of.buildGUI();		
		Selects se = new Selects(p0,EdairyUI.this,insert8,delete8,update8,view8);
		se.buildGUI();		
		Customer_login cl = new Customer_login(p0,EdairyUI.this,insert9,delete9,update9,view9);
		cl.buildGUI();		
		addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent we) 
			{ 
				closeWindow();
			} 
		}); 		
}
public EdairyUI() {
		initialize();
		addComponentsToFrame();
		register();
		pack();
		setTitle("Dairy Management System");
		setSize(600,600);
		setVisible(true);
	}
}