package Edairy;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Company{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton insertButton,deleteButton,updateButton,viewButton;
	private JPanel p1,p2,p3,p;
	private JLabel lblcompany_id,lblcompany_name;
	private JTextField txtcompany_id,txtcompany_name;	
	private List CompanyIDList;
	Connection con;ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public Company(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();		
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;	
		lblcompany_id=new JLabel("Company ID");
		lblcompany_name=new JLabel("company_name");		
		txtcompany_id=new JTextField(15);
		txtcompany_name=new JTextField(15);		
		this.p=p;	
	}
	public void connectToDB() 
    {
		try {
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","joshua","vasavi");  
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");		
	}
	public void loadCompanyIDs() {
		try {
			CompanyIDList.removeAll();
			rs=statement.executeQuery("select company_id from company");
			while(rs.next()) {
				CompanyIDList.add(rs.getString("company_id"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}
	public void buildGUI() {		
		insert.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				insertButton=new JButton("Submit");
				txtcompany_id.setText(null);
				txtcompany_name.setText(null);
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				p1=new JPanel();
				 p1.setLayout(new GridLayout(2,2));
				 p1.add(lblcompany_id);
				 p1.add(txtcompany_id);
				 p1.add(lblcompany_name);
				 p1.add(txtcompany_name);
				 p3=new JPanel(new FlowLayout());
				 p3.add(insertButton);
				p3.setBounds(200,220,75,35); p1.setBounds(100,80,300,100);
				 p2 = new JPanel(new FlowLayout());
				 CompanyIDList=new List(10);
				 loadCompanyIDs();
				 p2.add(CompanyIDList);//p2.setBackground(Color.cyan) ;					 
					 p2.setBounds(70,320,350,180);  
				 p. add(p1);p.add(p3);
				 p. add(p2);	
				 p.setLayout(new BorderLayout());				
					frame.add(p);
					frame.setSize(600,600);
					frame.validate();				
				 insertButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO company VALUES("+txtcompany_id.getText()+",'"+txtcompany_name.getText()+"')";					
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\ninserted "+i+" rows succesfully");
					loadCompanyIDs();					
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}		
				 }
				 	});
			}
			});
		delete.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("Delete");			
				txtcompany_id.setText(null);
				txtcompany_name.setText(null);
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();				
				p1=new JPanel();			
				p1.setLayout(new GridLayout(2,2));
				 p1.add(lblcompany_id);
				 p1.add(txtcompany_id);
				 p1.add(lblcompany_name);
				 p1.add(txtcompany_name);
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				p3.setBounds(200,220,75,35); p1.setBounds(100,80,300,100);
				 p2 = new JPanel(new FlowLayout());
				 CompanyIDList=new List(10);
				 loadCompanyIDs();
				 p2.add(CompanyIDList);					 
					 p2.setBounds(70,320,350,180);  
				 p. add(p1);p.add(p3);
				 p. add(p2);	
				 p.setLayout(new BorderLayout());			
					frame.add(p);
					frame.setSize(600,600);
					frame.validate();
				 CompanyIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from company");
								while (rs.next()) 
								{
									if (rs.getString("company_id").equals(CompanyIDList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtcompany_id.setText(rs.getString("company_id"));
									txtcompany_name.setText(rs.getString("company_name"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});					
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {					
					int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
					if(a==JOptionPane.YES_OPTION){  
					String query="DELETE FROM company WHERE company_id="+CompanyIDList.getSelectedItem();				
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");loadCompanyIDs();
					}					
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}				
				 }
				 	});
			}
			});		
		update.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				updateButton = new JButton("Modify");
				txtcompany_id.setText(null);
				txtcompany_name.setText(null);
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();				
				p1=new JPanel();		
				p1.setLayout(new GridLayout(2,2));
				 p1.add(lblcompany_id);
				 p1.add(txtcompany_id);
				 p1.add(lblcompany_name);
				 p1.add(txtcompany_name);
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				p3.setBounds(200,220,75,35); p1.setBounds(100,80,300,100);
				 p2 = new JPanel(new FlowLayout());
				 CompanyIDList=new List(10);
				 loadCompanyIDs();
				 p2.add(CompanyIDList);		 
					 p2.setBounds(70,320,350,180);  
				 p. add(p1);p.add(p3);
				 p. add(p2);	
				 p.setLayout(new BorderLayout());
					frame.add(p);
					frame.setSize(600,600);
					frame.validate();
				 CompanyIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from company");
								while (rs.next()) 
								{
									if (rs.getString("company_id").equals(CompanyIDList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtcompany_id.setText(rs.getString("company_id"));
									txtcompany_name.setText(rs.getString("company_name"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});						
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 try {								
								int a=JOptionPane.showConfirmDialog(p,"Are you sure want to update:");
								if(a==JOptionPane.YES_OPTION){  
								String query="update company set company_name='"+txtcompany_name.getText()+"' WHERE company_id="+CompanyIDList.getSelectedItem();								
								int i=statement.executeUpdate(query);
								JOptionPane.showMessageDialog(p,"\nupdated "+i+" rows succesfully");loadCompanyIDs();
								}	
							}
							catch(SQLException deleteException){
								displaySQLErrors(deleteException);
							}
				 }			
				 	});
			}
			});		
		view.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub			
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				Label view1=new Label("Company view");
				Font myFont = new Font("Serif",Font.BOLD,40);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p1.add(view1);
				p2=new JPanel(new FlowLayout());
                p2.add(viewButton);
                p2.setBounds(220,220,75,35);
                p1.setBounds(130,20,300,100);
                p.add(p1);
                p.add(p2);
                p.setLayout(new BorderLayout());
                frame.add(p);
				frame.setSize(600,600);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						    JTable j; 
						        f = new JFrame(); 
						        f.setTitle("Company Details"); 
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						       model.addColumn("Company ID");
						       model.addColumn("company_name");						      
						       try {
									rs=statement.executeQuery("select * from company");
									while(rs.next()) {
										 model.addRow(new Object[]{rs.getString("company_id"),rs.getString("company_name")});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 150, 150); 
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp);         
						        f.setSize(400, 400); 
						        f.setVisible(true);  
						    } 
				 	});	
			}
		});
	}	
}
