package Edairy;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class login {
	private static final long serialVersionUID = 1L;
	private JButton loginButton,deleteButton,viewButton,updateButton;
	private JPanel p1,p2,p3,p;
	private JLabel lbllog_id,lblName,lblpwd;
	private JTextField txtlog_id,txtName,txtpwd;
	private List loginIDList;
	Connection con;ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public login(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{	
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		lbllog_id=new JLabel("Login_ID");
		lblName=new JLabel("Name");
		lblpwd=new JLabel("Password");
		txtlog_id=new JTextField(15);
		txtName=new JTextField(15);
		txtpwd=new JPasswordField(8);	
		this.p=p;	
	}
	public void connectToDB() 
    {
		try {
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","joshua","vasavi"); 
		statement=con.createStatement(); 
		statement.executeUpdate("commit");		
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");	
	}
	public void loadLogins() {
		try {
			loginIDList.removeAll();
			rs=statement.executeQuery("select login_id from login");
			while(rs.next()) {
				loginIDList.add(rs.getString("login_ID"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}
	public void buildGUI() {
		loginButton=new JButton("Submit");	
		insert.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub			
				txtlog_id.setText(null);
				txtName.setText(null);
				txtpwd.setText(null); 				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();	   
				p1=new JPanel();
				 p1.setLayout(new GridLayout(3,2));
				 p1.add(lbllog_id);
				 p1.add(txtlog_id);
				 p1.add(lblName);
				 p1.add(txtName);
				 p1.add(lblpwd);
				 p1.add(txtpwd);
				 p3=new JPanel(new FlowLayout());
				 p3.add(loginButton);
				p3.setBounds(200,250,75,35);
				 p1.setBounds(115,80,300,150);
				 p2 = new JPanel(new FlowLayout());
					 loginIDList=new List(10);
					 loadLogins();
					 p2.add(loginIDList);
					 p2.setBounds(100,320,300,180);  
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);	
				 p.setLayout(new BorderLayout());
					frame.add(p);
					frame.setSize(600,600);
					frame.validate();
				 loginButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO login VALUES("+txtlog_id.getText()+",'"+txtName.getText()+"','"+txtpwd.getText()+"')";
					
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\ninserted "+i+" rows succesfully"); 
					loadLogins();
					System.out.println("done");
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				 }
				 	});
			}
			});
		delete.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("Delete");
				txtlog_id.setText(null);
				txtName.setText(null);
				txtpwd.setText(null); 
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				p1=new JPanel();
				p1.setLayout(new GridLayout(3,2));
				 p1.add(lbllog_id);
				 p1.add(txtlog_id);
				 p1.add(lblName);
				 p1.add(txtName);
				 p1.add(lblpwd);
				 p1.add(txtpwd);
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				p3.setBounds(200,250,75,35);
				 p1.setBounds(115,80,300,150);
				 p2 = new JPanel(new FlowLayout());
					 loginIDList=new List(10);
					 loadLogins();
					 p2.add(loginIDList);
					 p2.setBounds(100,320,300,180); 
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 p.setLayout(new BorderLayout());
					frame.add(p);
					frame.setSize(600,600);
					frame.validate();
				 loginIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from login");
								while (rs.next()) 
								{
									if (rs.getString("login_id").equals(loginIDList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtlog_id.setText(rs.getString("login_id"));
									txtName.setText(rs.getString("Name"));
									txtpwd.setText(rs.getString("password")); 	
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});	
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String password=JOptionPane.showInputDialog(p,"Enter the password");
					txtpwd.setText(password);
					int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
					if(a==JOptionPane.YES_OPTION){  
					String query="DELETE FROM LOGIN WHERE LOGIN_ID="+txtlog_id.getText()+"AND PASSWORD='"+txtpwd.getText()+"'";
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");
					loadLogins();
					}	
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				 }
				 	});
			}
			});
		update.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
					updateButton = new JButton("Modify");
				txtlog_id.setText(null);
				txtName.setText(null);
				txtpwd.setText(null); 
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				p1=new JPanel();
				p1.setLayout(new GridLayout(3,2));
				 p1.add(lbllog_id);
				 p1.add(txtlog_id);
				 p1.add(lblName);
				 p1.add(txtName);
				 p1.add(lblpwd);
				 p1.add(txtpwd);
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				p3.setBounds(200,250,75,35);
				 p1.setBounds(115,80,300,150);
				 p2 = new JPanel(new FlowLayout());
					 loginIDList=new List(10);
					 loadLogins();
					 p2.add(loginIDList);
					 p2.setBounds(100,320,300,180);  
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 p.setLayout(new BorderLayout());
					frame.add(p);
					frame.setSize(600,600);
					frame.validate();
				 loginIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from login");
								while (rs.next()) 
								{
									if (rs.getString("login_id").equals(loginIDList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtlog_id.setText(rs.getString("login_id"));
									txtName.setText(rs.getString("Name"));
									txtpwd.setText(rs.getString("password")); 
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});	
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					loadLogins();
					String password=JOptionPane.showInputDialog(p,"Enter the new password");
					txtpwd.setText(password);
					 String query=" update login set password='"+password+"' where login_id="+txtlog_id.getText();
					 int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nUpdated "+i+" rows succesfully");
					loadLogins();	
				}
				catch(SQLException updateException){	
					displaySQLErrors(updateException);
				}
				 }
				 	});
			}
			});
		view.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
                Label view1=new Label("View logins");
                Font myFont = new Font("Serif",Font.BOLD,50);
                view1.setFont((myFont));
                viewButton=new JButton("View");
                p1=new JPanel();
                p1.add(view1);
                p2=new JPanel(new FlowLayout());
                p2.add(viewButton);
                p2.setBounds(220,220,75,35);
                p1.setBounds(130,20,300,100);
                p.add(p1);
                p.add(p2);
                p.setLayout(new BorderLayout());
                frame.add(p);
				frame.setSize(600,600);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						    JTable j; 
						        f = new JFrame(); 
						        f.setTitle("login details"); 
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						       model.addColumn("login_id");
						       model.addColumn("Name");
						       model.addColumn("password");
						       try {
									rs=statement.executeQuery("select * from login");
									while(rs.next()) {
										 model.addRow(new Object[]{rs.getString("login_id"), rs.getString("Name"),rs.getString("password")});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 150, 150); 
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp); 			        
						        f.setSize(400, 400); 						      
						        f.setVisible(true); 					        
						    } 
				 	});	
			}			
		});		
	}	
}

