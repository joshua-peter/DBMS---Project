package Edairy;

import java.awt.BorderLayout;
import java.awt.Choice;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;
import java.util.StringTokenizer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Orders_from{
	private static final long serialVersionUID = 1L;
	private JButton insertButton,deleteButton,updateButton,viewButton;
	private JPanel p1,p2,p3,p;
	private JLabel lblCompany_ID,lblcustomer_id,lblday;
	private JTextField txtday,txtcustomer_id,txtCompany_ID;
	private Choice Company_ID,customer_id;
	
	private List orderfromIDList;
	Connection con;ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public Orders_from(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		
		lblCompany_ID=new JLabel("Company_ID");
		lblcustomer_id=new JLabel("Customer ID");
		lblday=new JLabel("Day");
		
		
		Company_ID=new Choice();
		customer_id=new Choice();
		txtday=new JTextField(8);
		txtcustomer_id=new JTextField(8);
		txtCompany_ID=new JTextField(8);
		
		this.p=p;
		
		
		
	}

	public void connectToDB() 
    {
		try {
		  
		
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","joshua","vasavi");  
		  
		 
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		
		
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
		
		
	}
	public void loadLoginIDs() {
		try {
			orderfromIDList.removeAll();
			rs=statement.executeQuery("select * from Orders_from");
			while(rs.next()) {
				orderfromIDList.add(rs.getString("customer_id")+"->"+rs.getString("Company_ID"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}
	
	public void loadcustomer() {
	try {
		customer_id.removeAll();
		rs=statement.executeQuery("select * from customer");
		while(rs.next()) {
			customer_id.add(rs.getString("customer_id"));
		}
		}
	catch(SQLException e) {
		displaySQLErrors(e);
	}
	}
	
	public void loadcompany() {
		try {
			Company_ID.removeAll();
			rs=statement.executeQuery("select * from company");
			while(rs.next()) {
				Company_ID.add(rs.getString("Company_ID"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
		}


	public void buildGUI() {
		
		
		
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				insertButton=new JButton("Submit");
				loadcustomer();
				loadcompany();
				txtday.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(3,1));
				 p1.add(lblcustomer_id);
				 p1.add(customer_id);
				 p1.add(lblCompany_ID);
				 p1.add(Company_ID);
				 p1.add(lblday);
				 p1.add(txtday);
				 p3=new JPanel(new FlowLayout());
				 p3.add(insertButton);
				 //p1.add(txtf1);
				// p3.setBackground(Color.);
				 p3.setBounds(200,330,75,35);
				 //p1.setBackground(Color.) ;
				 p1.setBounds(100,72,300,200);
				 p2 = new JPanel(new FlowLayout());
					 orderfromIDList=new List(10);
					 loadLoginIDs();
					 p2.add(orderfromIDList);
					// p2.setBackground(Color.);
					 p2.setBounds(340,100,300,180);  
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 p.setLayout(new BorderLayout());
					frame.add(p);
					frame.setSize(600,600);
					frame.validate();
					
				 insertButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO Orders_from VALUES("+customer_id.getSelectedItem()+","+Company_ID.getSelectedItem()+",'"+txtday.getText()+"')";
					
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\ninserted "+i+" rows succesfully");
					
					loadLoginIDs() ;
					
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("Delete");
				//deleteButton.setSize(1,1);
				txtCompany_ID.setText(null);
				txtcustomer_id.setText(null);
				txtday.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
				
			
				p1.setLayout(new GridLayout(3,1));
				 p1.add(lblcustomer_id);
				 p1.add(customer_id);
				 p1.add(lblCompany_ID);
				 p1.add(Company_ID);
				 p1.add(lblday);
				 p1.add(txtday);
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				 //p1.add(txtf1);
				// p3.setBackground(Color.);
				 p3.setBounds(200,330,75,35);
				 //p1.setBackground(Color.) ;
				 p1.setBounds(100,72,300,200);
				 p2 = new JPanel(new FlowLayout());
					 orderfromIDList=new List(10);
					 loadLoginIDs();
					 p2.add(orderfromIDList);
					// p2.setBackground(Color.);
					 p2.setBounds(340,100,300,180);  
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 p.setLayout(new BorderLayout());
					frame.add(p);
					frame.setSize(600,600);
					frame.validate();
				 
				 orderfromIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from Orders_from");
								StringTokenizer st=new StringTokenizer(orderfromIDList.getSelectedItem(),"->");
								String p=st.nextToken();
								String q=st.nextToken();
								
								while (rs.next()) 
								{
									if (rs.getString("customer_id").equals(p) && rs.getString("Company_ID").equals(q))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtcustomer_id.setText(rs.getString("customer_id"));
									txtCompany_ID.setText(rs.getString("Company_ID"));
									txtday.setText(rs.getString("day"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});		
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					
					int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
					if(a==JOptionPane.YES_OPTION){  
						StringTokenizer st=new StringTokenizer(orderfromIDList.getSelectedItem(),"->");
				
					String query="DELETE FROM Orders_from WHERE customer_id="+st.nextToken()+" AND Company_ID="+st.nextToken();
				
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");loadLoginIDs();
					}
					
					
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				updateButton = new JButton("Modify");
				txtCompany_ID.setText(null);
				txtcustomer_id.setText(null);
				txtday.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
				
			
				p1.setLayout(new GridLayout(3,1));
				 p1.add(lblcustomer_id);
				 p1.add(customer_id);
				 p1.add(lblCompany_ID);
				 p1.add(Company_ID);
				 p1.add(lblday);
				 p1.add(txtday);
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				 //p1.add(txtf1);
				// p3.setBackground(Color.);
				 p3.setBounds(200,330,75,35);
				 //p1.setBackground(Color.) ;
				 p1.setBounds(100,72,300,200);
				 p2 = new JPanel(new FlowLayout());
					 orderfromIDList=new List(10);
					 loadLoginIDs();
					 p2.add(orderfromIDList);
					// p2.setBackground(Color.);
					 p2.setBounds(340,100,300,180);  
				 p. add(p1);
				 p.add(p3);
				 p. add(p2);
				 p.setLayout(new BorderLayout());
					frame.add(p);
					frame.setSize(600,600);
					frame.validate();
				 
				 orderfromIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from Orders_from");
								StringTokenizer st=new StringTokenizer(orderfromIDList.getSelectedItem(),"->");
								String p=st.nextToken();
								String q=st.nextToken();
								
								while (rs.next()) 
								{
									if (rs.getString("customer_id").equals(p) && rs.getString("Company_ID").equals(q))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtcustomer_id.setText(rs.getString("customer_id"));
									txtCompany_ID.setText(rs.getString("Company_ID"));
									txtday.setText(rs.getString("day"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});			
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 try {
								
								int a=JOptionPane.showConfirmDialog(p,"Are you sure want to update:");
								if(a==JOptionPane.YES_OPTION){  
									StringTokenizer st=new StringTokenizer(orderfromIDList.getSelectedItem(),"->");
								String query="update Orders_from set customer_id="+txtcustomer_id.getText()+",Company_ID="+txtCompany_ID.getText()+",day='"+txtday.getText()+"' WHERE customer_id="+st.nextToken()+"and Company_ID="+st.nextToken();
								
								int i=statement.executeUpdate(query);
								JOptionPane.showMessageDialog(p,"\nupdated "+i+" rows succesfully");loadLoginIDs() ;
								}
								
								
							}
							catch(SQLException deleteException){
								displaySQLErrors(deleteException);
							}
				
				 }
			
			
				 	});
			}
			});
		
		view.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				Label view1=new Label("Company Order");
				//view1.setAlignment(Label.CENTER); 
				Font myFont = new Font("Serif",Font.BOLD,40);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p1.add(view1);
				
				
				p2=new JPanel(new FlowLayout());
                p2.add(viewButton);
                p2.setBounds(220,220,75,35);
                p1.setBounds(130,20,300,100);
                p.add(p1);
                p.add(p2);
                p.setLayout(new BorderLayout());
                frame.add(p);
				
				
				
				frame.setSize(600,600);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						      
						    JTable j; 
						
						        f = new JFrame(); 
						  
						  
						        f.setTitle("Customer Login company"); 
						        
						       
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						       model.addColumn("customer_id");
						       model.addColumn("Company_ID");
						       model.addColumn("day");
						      
						       try {
									
									rs=statement.executeQuery("select * from Orders_from");
									while(rs.next()) {
										 model.addRow(new Object[]{rs.getString("customer_id"), rs.getString("Company_ID"),rs.getString("day")});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 150, 150); 
						  
						        
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp); 
						        
						        f.setSize(400, 400); 
						      
						        f.setVisible(true); 
						       
						        
						    } 
						        
				
				 
			
			
				 	});
				
			        
				
			}
			
		});
		
	}
	
	
	
}