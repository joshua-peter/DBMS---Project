package Edairy;

import java.awt.BorderLayout;
import java.awt.Choice;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;
import java.util.StringTokenizer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Customer {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton insertButton,deleteButton,updateButton,viewButton;
	private JPanel p1,p2,p3,p;
	private JLabel lblcustomer_id,lblcustomer_name,lblpno,lblemail,lbladd;
	private JTextField txtcustomer_id,txtcustomer_name,txtpno,txtemail;
	private JTextArea txtadd;
	private List customerIDList;
	Connection con;ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public Customer(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		
		//lbllog_id=new JLabel("Login_id");
		lblcustomer_id=new JLabel("customer_id");
		lblcustomer_name=new JLabel("customer_name");
		lblpno=new JLabel("phone_no");
		lblemail=new JLabel("email");
		lbladd=new JLabel("address");
		
		//txtlog_id = new JTextField(15);
		txtcustomer_id=new JTextField(15);
		txtcustomer_name=new JTextField(15);
		txtpno=new JTextField(15);
		txtemail=new JTextField(30);
		txtadd=new JTextArea(15,15);
		
		this.p=p;
		
		
		
	}

	public void connectToDB() 
    {
		try {
		  
		
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","joshua","vasavi");  
		  
		 
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		
		
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
		
		
	}
	public void loadcustomerIDs() {
		try {
			customerIDList.removeAll();
			rs=statement.executeQuery("select customer_id from Customer");
			while(rs.next()) {
				customerIDList.add(rs.getString("customer_id"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}
	public void buildGUI() {
		
		
		
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				insertButton=new JButton("Submit");
				txtcustomer_id.setText(null);
				txtcustomer_name.setText(null);
				txtpno.setText(null);
				txtemail.setText(null);
				txtadd.setText(null);
				//txtlog_id.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				//loadlogin();
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(5,2));
				 p1.add(lblcustomer_id);
				 p1.add(txtcustomer_id);
				 p1.add(lblcustomer_name);
				 p1.add(txtcustomer_name);
				 p1.add(lblpno);
				 p1.add(txtpno);
				 p1.add(lblemail);
				 p1.add(txtemail);
				 p1.add(lbladd);
				 p1.add(txtadd);
				 //p1.setBackground(Color.pink) ;
				 p3=new JPanel(new FlowLayout());
				 p3.add(insertButton);
				 //p1.add(txtf1);
				 //p3.setBackground(Color.yellow);
				p3.setBounds(160,450,75,35);	 
				 p1.setBounds(50,50,350,320);
				 p2 = new JPanel(new FlowLayout());
				 customerIDList=new List(10);
				 loadcustomerIDs();
				 p2.add(customerIDList);//p2.setBackground(Color.cyan) ;
				 p2.setBounds(330,150,350,180);
				 p. add(p1);
				 p.add(p3);   
				 p. add(p2);
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(600,600);
					frame.validate();
					
				 insertButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO Customer VALUES('"+txtcustomer_id.getText()+"','"+txtcustomer_name.getText()+"','"+txtpno.getText()+"','"+txtemail.getText()+"','"+txtadd.getText()+"')";
					
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\ninserted "+i+" rows succesfully");
					
					loadcustomerIDs();
					//loadlogin();
					
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				
				 }
			
			
				 	});
			}
			});

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("Delete");
				
				txtcustomer_id.setText(null);
				txtcustomer_name.setText(null);
				txtpno.setText(null);
				txtemail.setText(null);
				txtadd.setText(null);
				//txtlog_id.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				p1=new JPanel();
				
				
				 p1.setLayout(new GridLayout(5,2));
				 p1.add(lblcustomer_id);
				 p1.add(txtcustomer_id);
				 p1.add(lblcustomer_name);
				 p1.add(txtcustomer_name);
				 p1.add(lblpno);
				 p1.add(txtpno);
				 p1.add(lblemail);
				 p1.add(txtemail);
				 p1.add(lbladd);
				 p1.add(txtadd);
				 //p1.setBackground(Color.pink) ;
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				 //p1.add(txtf1);
				 //p3.setBackground(Color.yellow);
				p3.setBounds(160,450,75,35);	 
				 p1.setBounds(50,50,350,320);
				 p2 = new JPanel(new FlowLayout());
				 customerIDList=new List(10);
				 loadcustomerIDs();
				 p2.add(customerIDList);//p2.setBackground(Color.cyan) ;
				 p2.setBounds(330,150,350,180);
				 p. add(p1);
				 p.add(p3);   
				 p. add(p2);
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(600,600);
					frame.validate();
				 customerIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from Customer");
								while (rs.next()) 
								{
									if (rs.getString("customer_id").equals(customerIDList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									//txtlog_id.setText(rs.getString("Login_id"));
									txtcustomer_id.setText(rs.getString("customer_id"));
									txtcustomer_name.setText(rs.getString("customer_name"));
									txtpno.setText(rs.getString("phone_no"));
									txtemail.setText(rs.getString("email"));
									txtadd.setText(rs.getString("address"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});			
				 
				 
				
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					
					int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
					if(a==JOptionPane.YES_OPTION){  
						String query="DELETE FROM customer WHERE customer_id="+customerIDList.getSelectedItem();
				
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");loadcustomerIDs();
					//loadlogin();
					}
					
					
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				
				 }
				 	});
			}
			});
		
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				updateButton = new JButton("Modify");
				
				txtcustomer_id.setText(null);
				txtcustomer_name.setText(null);
				txtpno.setText(null);
				txtemail.setText(null);
				txtadd.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				p1=new JPanel();
				
				p1.setLayout(new GridLayout(5,2));
				 p1.add(lblcustomer_id);
				 p1.add(txtcustomer_id);
				 p1.add(lblcustomer_name);
				 p1.add(txtcustomer_name);
				 p1.add(lblpno);
				 p1.add(txtpno);
				 p1.add(lblemail);
				 p1.add(txtemail);
				 p1.add(lbladd);
				 p1.add(txtadd);
				 //p1.setBackground(Color.pink) ;
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				 //p1.add(txtf1);
				 //p3.setBackground(Color.yellow);
				p3.setBounds(160,450,75,35);	 
				 p1.setBounds(50,50,350,320);
				 p2 = new JPanel(new FlowLayout());
				 customerIDList=new List(10);
				 loadcustomerIDs();
				 p2.add(customerIDList);//p2.setBackground(Color.cyan) ;
				 p2.setBounds(330,150,350,180);
				 p. add(p1);
				 p.add(p3);   
				 p. add(p2);
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(600,600);
					frame.validate();
				 customerIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from Customer");
								while (rs.next()) 
								{
									if (rs.getString("customer_id").equals(customerIDList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									//txtlog_id.setText(rs.getString("Login_id"));
									txtcustomer_id.setText(rs.getString("customer_id"));
									txtcustomer_name.setText(rs.getString("customer_name"));
									txtpno.setText(rs.getString("phone_no"));
									txtemail.setText(rs.getString("email"));
									txtadd.setText(rs.getString("address"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});			
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 try {
								int a=JOptionPane.showConfirmDialog(p,"Are you sure want to update:");
								if(a==JOptionPane.YES_OPTION){ 
								String query="update Customer set customer_name='"+txtcustomer_name.getText()+"',phone_no="+txtpno.getText()+",email='"+txtemail.getText()+"',address='"+txtadd.getText()+"' WHERE customer_id="+customerIDList.getSelectedItem();
								int i=statement.executeUpdate(query);
								JOptionPane.showMessageDialog(p,"\nupdated "+i+" rows succesfully");loadcustomerIDs();
								}
							}
							catch(SQLException deleteException){
								displaySQLErrors(deleteException);
							}
				 }
				 	});
			}
			});
		view.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				Label view1=new Label("CustomerAccount view");
				//view1.setAlignment(Label.CENTER); 
				Font myFont = new Font("Serif",Font.BOLD,28);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p1.add(view1);
				p2=new JPanel(new FlowLayout());
                p2.add(viewButton);
                p2.setBounds(220,220,75,35);
                p1.setBounds(130,20,300,100);
                p.add(p1);
                p.add(p2);
                p.setLayout(new BorderLayout());
                frame.add(p);
				frame.setSize(600,600);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						    JTable j; 
						        f = new JFrame(); 
						        f.setTitle("login_User details"); 
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						       model.addColumn("customer_id");
						       model.addColumn("customer_name");
						       model.addColumn("phone_no");
						       model.addColumn("E-Mail");
						       model.addColumn("Address");
						       try {
									rs=statement.executeQuery("select * from Customer");
									while(rs.next()) {
										 model.addRow(new Object[]{rs.getString("customer_id"), rs.getString("customer_name"),rs.getString("phone_no"),rs.getString("email"),rs.getString("address"),});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 300, 300); 
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp); 
						        f.setSize(800, 400); 
						        f.setVisible(true);   
						    } 
				 	});	
			}			
		});
	}	
}
